# Wilma Waschen

Retro-Waschsalonspiel im Zelda-Stil.

## Einbettung
```html
<iframe src="https://mot-dotcom.github.io/wilma-waschen/" width="800" height="600" style="border:none;"></iframe>
```